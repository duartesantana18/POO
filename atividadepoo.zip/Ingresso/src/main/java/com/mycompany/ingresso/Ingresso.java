/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ingresso;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class Ingresso {
    
    public static void main(String []args){
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite 1 para Ingresso Normal e 2 para Ingresso VIP: ");
        int tipoIngresso = scanner.nextInt();
        Ingresso ingresso;
        
        if (tipoIngresso == 1){
            System.out.println("Ingresso Normal ");
        }else{
            System.out.println("Ingresso VIP! Digite 1 para camarote superior e 2 para camarote inferior");
            int tipovip = scanner.nextInt();
                    
            VIP v1 = new VIP(tipovip);
            v1.imprimirValor();
        }
        
        
    }
    
        
    
        
    
}
