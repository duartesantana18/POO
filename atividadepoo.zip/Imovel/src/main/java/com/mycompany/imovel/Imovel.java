/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.imovel;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class Imovel {
    
    public static void main(String []args){
    
        Scanner scanner = new Scanner(System.in);
            int tipoimovel = scanner.nextInt();
        Imovel imovel;
        
        
        System.out.println("Digite número 1 para Imovel novo e 2 para Imovel velho: ");
        int valorimovel = scanner.nextInt();
        valorimovel = 200000;
        int valorimovelvelho = scanner.nextInt();
        valorimovelvelho = 100000;
        
        if(tipoimovel == 1 ){
            System.out.println("O valor do Imovel novo é de: R$" + valorimovel);
        }else{
            System.out.println("O valor do imovel velho é de: R$" + valorimovelvelho);
        }
    }
    
}
