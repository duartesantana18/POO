/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionario;

/**
 *
 * @author Admin
 */
public class Assisadmin extends Funcionario{
    
    public Assisadmin(String nome, int matricula){
        super(nome, matricula);
    }
    
}
