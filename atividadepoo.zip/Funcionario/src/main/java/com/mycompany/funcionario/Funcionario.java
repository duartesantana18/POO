/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.funcionario;

/**
 *
 * @author Admin
 */
public class Funcionario {
    
    public String nome;
    public int matricula;
    
    public Funcionario(String nome, int matricula){
        this.nome = nome;
        this.matricula = matricula;
    }
    public static void main(String []args){
        Assisadmin admin1 = new Assisadmin("Emerson", 30122);
        admin1.print();
        
        Tecnico tec1 = new Tecnico("Steve", 12222);
        tec1.print();
    }
    
    
    
    
    public void print(){
        System.out.println("Nome: " + nome + ",Matricula:" + matricula);
}
    
}
