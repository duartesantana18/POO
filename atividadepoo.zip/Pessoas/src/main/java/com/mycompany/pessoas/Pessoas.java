/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pessoas;

/**
 *
 * @author Admin
 */
public class Pessoas {
    
    public String nome;
    
    public Pessoas(String nome){
        this.nome = nome;
    }
    public static void main(String []args){
        
        RIca prica = new RIca("Maria");
            prica.print();
            
        Pobre ppobre = new Pobre("Cicero");
            ppobre.print();
            
        Miseravel pmiser = new Miseravel("Paulo");
            pmiser.print();
    }
    
    public void print(){
        System.out.println("Nome:" + nome);
    }
}
